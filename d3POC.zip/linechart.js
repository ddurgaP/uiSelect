var linedata = [{
    "key": "ABC",
    "color": "#B276B2",
    "values": [{
        "Client": "ABC",
        "sale": "202",
        "year": "2000"
    }, {
        "Client": "ABC",
        "sale": "215",
        "year": "2002"
    }, {
        "Client": "ABC",
        "sale": "179",
        "year": "2004"
    }, {
        "Client": "ABC",
        "sale": "199",
        "year": "2006"
    }, {
        "Client": "ABC",
        "sale": "134",
        "year": "2008"
    }, {
        "Client": "ABC",
        "sale": "270",
        "year": "2011"
    }]
}, {
    "key": "XYZ",
    "color": "#FF6D00",
    "values": [{
        "Client": "XYZ",
        "sale": "100",
        "year": "2000"
    }, {
        "Client": "XYZ",
        "sale": "250",
        "year": "2002"
    }, {
        "Client": "XYZ",
        "sale": "179",
        "year": "2004"
    }, {
        "Client": "XYZ",
        "sale": "199",
        "year": "2006"
    }, {
        "Client": "XYZ",
        "sale": "134",
        "year": "2008"
    }, {
        "Client": "XYZ",
        "sale": "176",
        "year": "2013"
    }]
}]




var lineConfig = {
    containerId: "lineContainer",
    width: 400,
    height: 400,
    labels: true,
    legend:true,
    data: linedata,
    xDomain:[2000,2015],
    yDomain:[100,300],
    //callback:segmentClick(),
    heading: {
        html: "<h2>Mobility</h2>",
    },

    showText:true,
    tooltip:true,
    inner: "drilldown",
    transition: "linear",
    transitionDuration: 750,
    interpolate:"basis"
}


var lineChart = function(config){
    var container = document.getElementById(config.containerId);
    container.innerHTML = config.heading.html;

	var data = config.data;
    var WIDTH = config.width;
	var HEIGHT = config.height;
	var MARGINS = {
        top: 50,
        right: 20,
        bottom: 50,
        left: 50
    }

	var div = document.createElement('div');
	var chart = d3.select(div);

	var vis = chart.append("svg")
	.attr("width",config.width)
	.attr("height",config.height)

    xScale = d3.scale.linear().range([MARGINS.left, WIDTH - MARGINS.right]).domain(config.xDomain);
    yScale = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain(config.yDomain);

    xAxis = d3.svg.axis()
        .scale(xScale).tickFormat(d3.format("d")),
  
    yAxis = d3.svg.axis()
        .scale(yScale);

    // vis.append("svg:g")
    //     .call(xAxis);

    vis.append("svg:g")
        .attr("class","axis")
        .attr("transform", "translate(0," + (HEIGHT - MARGINS.bottom) + ")")
        .call(xAxis);

    // vis.append("svg:g")
    //     .call(yAxis);

    yAxis = d3.svg.axis()
        .scale(yScale)
        .orient("left");

    vis.append("svg:g")
        .attr("class","axis")
        .attr("transform", "translate(" + (MARGINS.left) + ",0)")
        .call(yAxis);

    var lineGen = d3.svg.line()
      .x(function(d) {
        return xScale(d.year);
      })
      .y(function(d) {
        return yScale(d.sale);
      })
      .interpolate(config.interpolate);


    var lSpace = WIDTH/config.data.length;

    data.forEach(function(d, i) {
        var path = vis.append('svg:path')
        .attr('d', lineGen(d.values))
        .attr('stroke', function() {
                if(d.color){
                    return d.color
                }else{
                    return "hsl(" + Math.random() * 360 + ",100%,50%)";
                }
            }
        )
        .attr('stroke-width', 2)
        .attr('fill', 'none')
        .attr('id', 'line_'+d.key);

        var totalLength = path.node().getTotalLength();

        path.attr("stroke-dasharray", totalLength + " " + totalLength)
        .attr("stroke-dashoffset", totalLength)
        .transition()
        .duration(1000)
        .ease("linear")
        .attr("stroke-dashoffset", 0);


        vis.append("text")
        .attr("x", (lSpace / 2) + i * lSpace)
        .attr("y", HEIGHT)
        .style("fill", d.color)
        .style("font-weight","bold")
        .style("cursor","pointer")
        .text(d.key)
        .on('click', function() {
            var active = d.active ? false : true;
            var opacity = active ? 0 : 1;
            d3.select("#line_" + d.key)
            .transition()
            .duration(500).style("opacity", opacity);
            d.active = active;
        });
    });
    document.getElementById(config.containerId).appendChild(div);
}
