var pieChart = function(config,callback){
    this.updating = false;
    var nbar = document.createElement("div");
    nbar.setAttribute("style","width:100%;height:40px;clear:both")
    var nav_ul = document.createElement("ul");
    nbar.className = "crumbs";
    nbar.appendChild(nav_ul);

    var container = document.getElementById(config.containerId);
    container.innerHTML = config.heading.html;
    container.setAttribute("style","display:block;width:"+ config.width +";height:"+ config.height);
    container.appendChild(nbar);


    //tooltip//
    if(config.tooltip){
        var t = document.createElement("div");
        container.appendChild(t);
        var tooltip = d3.select(t);
        tooltip.attr("class","toolTip")
    }
    ///////////
    
    var width = container.clientWidth;
    var height = container.clientHeight;

    var me = this;
    this.prev_data = config.data;

    this.curr_level = 0;
    this.label_arr = [];


    var radius = Math.min(width,height-40)/2;
    if(config.legend){
        radius = (width)/3;
    }
    var pie = d3.layout.pie()
        .value(function(d){ return d.value })
        .sort(null);

    var arc = d3.svg.arc()
            .innerRadius(config.donutRadius)
            .outerRadius(radius - 20);

    var tx = (config.legend)?(width/3):(width/2)

    var svg = d3.select('#'+config.containerId)
        .append("svg")
        .attr("width",'100%')
        .attr("height",'100%')
        .attr('viewBox','0 0 '+Math.min(width,height) +' '+Math.min(width,height) )
        .attr('preserveAspectRatio','xMinYMin')
        .append("g")
        .attr("transform","translate("+ tx +","+ (height-40)/2 +")")
        .attr("font","sans-serif")
        .attr("font-size","18px")

    var arc_grp = svg.append("svg:g")
        .attr("class", "arcGrp")

    var center_group = svg.append("svg:g")
        .attr("class", "ctrGroup")

    var label_group = svg.append("svg:g")
        .attr("class", "lblGroup");

    var nav_group = svg.append("svg:g")
        .attr("class","nav_group");

    var legend_group = svg.append("svg:g")
        .attr("class","legend_group")

    var path = arc_grp.selectAll("path")
        .data(pie(config.data));
    
    var sliceLabel = label_group.selectAll("text")
        .data(pie(config.data))
        .attr("text-anchor", "middle");

    // var tip = d3.tip()
    //   .attr('class', 'd3-tip')
    //   .offset([-10, 0])
    //   .html(function(d) {
    //     config.tooltip
    //   });

    path.enter()
        .append("svg:path")
        .attr("fill",function(d){
            return d.data.color
        })
        .style("cursor",function(d){
            if(d.data.sub){
                return "pointer"
            }
        })
        .on("click",function(d){
            var segment = d3.select(this);
            if(d.data.sub){
                me.updating = true;
                me.update(d.data.sub,me.prev_data,d.data.text,d.data.color);
                me.curr_level++;
            }
            callback(d);
        })
        .transition().delay(function(d, i) {return i}).duration(config.transitionDuration)
        .attrTween('d', function(d) {
            var i = d3.interpolate(d.startAngle+0.1, d.endAngle);
            return function(t) {
                d.endAngle = i(t);
                return arc(d);
            }
        })
        .each(function(d) {
            this._current = d;
        })
    path.exit().remove()

    if(config.tooltip){
        path.on("mousemove", function(d){
            tooltip.style("left", d3.event.pageX+10+"px");
            tooltip.style("top", d3.event.pageY-25+"px");
            tooltip.style("display", "inline-block");
            tooltip.style("opacity","0");
            tooltip.transition()
            .duration(500).
            style("opacity", "100");
            tooltip.html((d.data.text)+"<br>"+(d.data.value));
        });

        path.on("mouseout", function(d){
            tooltip.transition().duration(500).style("opacity", "0");
        });
    }

    if(config.labels){
        sliceLabel.enter().append("svg:text")
            .attr("class", "arcLabel")
            .attr("transform", function(d) {
                return "translate(" + arc.centroid(d) + ")"; })
            .attr("text-anchor", "middle").text(function(d) {
                return d.value });

        sliceLabel.transition()
            .duration(750)
            .attr("transform", function(d) {
                return "translate(" + arc.centroid(d) + ")";
            })
            .style("font-family","sans-serif")
            .style("font-size",16)
            .style("fill",config.labelColor);

        sliceLabel.exit().remove();
    }


   this.drawLegend=function(ldata){
        var legendRectSize = 18;
        var legendSpacing = 10;
        //var font_size = 14;
        svg.select('.legend_group').selectAll("g").remove();

        var legend = svg.select('.legend_group')
            .selectAll("g")
            .data(ldata)
            .enter()
            .append('g')
            .attr('class', 'legend')
            .attr('transform', function(d, i) {
                var length = this.parentNode.childNodes.length;
                var height = legendRectSize + legendSpacing;
                var offset =  height * length / 2;
                var horz = -2 * legendRectSize;
                var vert = i * height - offset;
                return 'translate(' + horz + ',' + vert + ')';
            });

        legend.append('rect')
            .attr('width', legendRectSize)
            .attr('height', legendRectSize)
            .style('fill', function(d){
                return d.color
            })
            .style('stroke', function(d){
                return d.color
            })
            .attr("opacity",0)
            .transition()
            .duration(750)
            .attr("opacity",1)
       
        legend.append('text')
            .attr('x', legendRectSize + legendSpacing)
            .attr('y', legendRectSize - 2.5)
            .text(function(d) { return d.text })
            .attr("fill",config.labelColor;
            .attr("opacity",0)
            .transition()
            .duration(750)
            .attr("opacity",1)


        var lg = d3.select(".legend_group")

        lg.attr("transform","translate("+ 0 +","+ 0 +")")
        .transition()
        .duration(750)
        .attr("transform","translate("+ (radius+legendRectSize+10) +","+ 0 +")")
    }

    if(config.legend){
        me.drawLegend(config.data);
    }


    this.update = function(newdata,prevdata,label,color){
        var enterAntiClockwise = {
          startAngle: Math.PI * 2,
          endAngle: Math.PI * 2
        };
        var k = 0;

        d3.select(".nav_group")
            .selectAll("text")
            .each(function(d){
                k = k + this.getBBox().width + 20;
            })
        if(prevdata){
            var li = document.createElement("li")
            var a = document.createElement("a");
            a.innerHTML = label;
            li.appendChild(a);
            li.style.backgroundColor = color;
            a.style.color = "#fff"
            a.style.borderColor = color;
            li.addEventListener("click",function(){
                me.update(prevdata);
                var ns;
                var curr_li = a.parentNode;
                while(ns = curr_li.nextSibling){
                    nav_ul.removeChild(ns);
                }
                nav_ul.removeChild(curr_li);
            })
            nav_ul.appendChild(li);
            // var selection = 0;
            // var nav = d3.select(".nav_group")
            //     .selectAll("g")
            //     .data(me.label_arr)
            //     .enter()
            //     .append("g");
                
            //     var rect = nav.append("rect")
            //     .attr("width",50)
            //     .attr("height",40)
            //     .attr("fill",color)
            //     .attr("x",40)
            //     .attr("y",50)
            //     .attr("stroke-width",2)
            //     .attr("stroke","#fff")
                
            //     var txt = nav.append("svg:text")
            //     .text(function(d,i){
            //         var t = d
            //         return d;
            //     })
            //     .attr("height",40)
            //     .attr("x",50)
            //     .attr("y",75)

            //     rect.attr("width",txt.node().getBBox().width + 20);
                

            //     nav.on("click",function(d){
            //         d3.select(".nav_group").selectAll("g")
            //         .each(function(t,i){
            //             if(t == d || selection == 1){
            //                 console.log("found" + i);
            //                 selection = 1;
            //                 d3.select(this).attr("class","sel");
            //             }
            //         })
            //         d3.select(".nav_group").selectAll(".sel").remove();
            //         //d3.select(this).remove();
            //         me.label_arr.length =  me.label_arr.indexOf(d);
            //         me.update(prevdata);
            //         k=0;
            //     })
            //     nav.attr("transform","translate("+ (-1*config.width/2 + 50 + k) + "," + (-1*config.height/2 + 10) + ")")
        }

        this.prev_data = newdata;

        path = path.data(pie(newdata));
        
        path.enter()
            .append("svg:path")
            .attr("d",arc(enterAntiClockwise))
            .style("cursor",function(d){
                if(d.data.sub){
                    return "pointer"
                }
            })
            .each(function(d){
                this._current = {
                    data : d.data,
                    value : d.value,
                    startAngle : enterAntiClockwise.startAngle,
                    endAngle : enterAntiClockwise.endAngle
                };
            })
            .on("click",function(d){
                var segment = d3.select(this);
                if(d.data.sub){
                    me.update(d.data.sub,prevdata,d.text);
                }
                callback(d)
            })
        path.exit()
            .transition()
            .duration(config.transitionDuration)
            .attrTween('d', this.arcTweenOut)
            .remove()


        path.transition().duration(config.transitionDuration).ease(config.drilldownTransition).attrTween("d", this.arcTween)
        .attr("fill", function(d) {
             return d.data.color;
         }); // redraw the arcs

        if(config.labels){
            label_group.selectAll("text").remove();

            var labels = label_group.selectAll("text")
                .data(pie(newdata));
                labels.enter().append("svg:text")
                .attr("text-anchor", "middle")
                .text(function(d){
                    return d.data.value
                })
                .style("font-family","sans-serif")
                .style("font-size",16)
                .attr("opacity",0)

            labels.transition()
                .duration(config.transitionDuration)
                .attr("opacity",1)
                .attr("transform", function(d) {
                    return "translate(" + arc.centroid(d) + ")";
                })

            labels.exit().remove();
        }

        if(config.legend){
            me.drawLegend(newdata);
        }
        setTimeout(function(){
        me.updating=false;
        },500);
    } 


     

    this.arcTween =function(a) {
      var i = d3.interpolate(this._current, a);
      this._current = i(0);
      return function(t) {
        return arc(i(t));
      };
    }
    this.arcTweenOut = function(a) {
      var i = d3.interpolate(this._current, {startAngle: Math.PI * 2, endAngle: Math.PI * 2, value: 0});
      this._current = i(0);
      return function (t) {
        return arc(i(t));
      };
    }
}

segmentClick = function(d){
    console.log(d);
}
var chart = new pieChart(config,segmentClick);




