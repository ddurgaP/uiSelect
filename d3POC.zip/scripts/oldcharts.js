pieData = {
    "type": "pie",
    "items": [
        {
            "id": 1,
            "color": "#7E57C2",
            "text": "BFS",
            "value": 30,
            "sub": {
                "type": "pie",
                "items": [
                    {
                        "id": "BFS1",
                        "color": "#00C853",
                        "text": "CBQ",
                        "value": 60,
                        "sub": null
                    },
                    {
                        "id": "BFS2",
                        "color": "#FFC107",
                        "text": "CITY",
                        "value": 20,
                        "sub": {
                            "type": "pie",
                            "items": [
                                {
                                    "id": "S1",
                                    "color": "#FF9800",
                                    "text": "Q1",
                                    "value": 10,
                                    "sub":null,
                                    "linkedchart": {
                                        "type": "line",
                                        "items": [
                                            {
                                                "id": "l1",
                                                "x": 1,
                                                "y": 5
                                            },
                                            {
                                                "id": "l2",
                                                "x": 20,
                                                "y": 20
                                            },
                                            {
                                                "id": "l3",
                                                "x": 40,
                                                "y": 10
                                            },
                                            {
                                                "id": "l4",
                                                "x": 60,
                                                "y": 40
                                            },
                                            {
                                                "id": "l5",
                                                "x": 80,
                                                "y": 5
                                            },
                                            {
                                                "id": "l6",
                                                "x": 100,
                                                "y": 60
                                            }
                                        ]
                                    }
                                },
                                {
                                    "id": "S2",
                                    "color": "#00BCD4",
                                    "text": "Q2",
                                    "value": 20,
                                    "sub": null,
                                    "linkedchart": {
                                        "type": "line",
                                        "items": [
                                            {
                                                "id": "l1",
                                                "x": 1,
                                                "y": 15
                                            },
                                            {
                                                "id": "l2",
                                                "x": 20,
                                                "y": 20
                                            },
                                            {
                                                "id": "l3",
                                                "x": 40,
                                                "y": 30
                                            },
                                            {
                                                "id": "l4",
                                                "x": 60,
                                                "y": 20
                                            },
                                            {
                                                "id": "l5",
                                                "x": 80,
                                                "y": 20
                                            },
                                            {
                                                "id": "l6",
                                                "x": 100,
                                                "y": 60
                                            }
                                        ]
                                    }
                                },
                                {
                                    "id": "S3",
                                    "color": "#E91E63",
                                    "text": "Q3",
                                    "value": 20,
                                    "sub": null,
                                    "linkedchart": {
                                        "type": "bar",
                                        "items": [
                                            {
                                                "id": "l1",
                                                "x": 1,
                                                "y": 50
                                            },
                                            {
                                                "id": "l2",
                                                "x": 20,
                                                "y": 60
                                            },
                                            {
                                                "id": "l3",
                                                "x": 40,
                                                "y": 30
                                            },
                                            {
                                                "id": "l4",
                                                "x": 60,
                                                "y": 70
                                            },
                                            {
                                                "id": "l5",
                                                "x": 80,
                                                "y": 40
                                            },
                                            {
                                                "id": "l6",
                                                "x": 100,
                                                "y": 60
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            "id": 2,
            "color": "#00BCD4",
            "text": "RETAIL",
            "value": 20,
            "sub": {
                "type": "pie",
                "items": [
                    {
                        "id": "RE1",
                        "color": "#00BCD4",
                        "text": "WALMART",
                        "value": 80,
                        "sub": null
                    },
                    {
                        "id": "RE2",
                        "color": "#5DA5DA",
                        "text": "HOMEDIPOT",
                        "value": 30,
                        "sub": null
                    },
                    {
                        "id": "RE3",
                        "color": "#DECF3F",
                        "text": "SPENCER",
                        "value": 50,
                        "sub": null
                    }
                ]
            }
        },
        {
            "id": 3,
            "color": "#4CAF50",
            "text": "TELECOM",
            "value": 40,
            "sub": {
                "type": "pie",
                "items": [
                    {
                        "id": "TE1",
                        "color": "#B276B2",
                        "text": "TALKTALK",
                        "value": 60,
                        "sub": null
                    },
                    {
                        "id": "TE2",
                        "color": "#4CAF50",
                        "text": "VODAFONE",
                        "value": 10,
                        "sub": null
                    },
                    {
                        "id": "TE3",
                        "color": "#FF6D00",
                        "text": "CISCO",
                        "value": 20,
                        "sub": null
                    }
                ]
            }
        }
    ]
}






function pie(divid, width, height, data, colors, isDonut){
	var div = document.createElement('div');
	div.id = "chart";

	this.width = width;
	this.height = height;
	this.data =  data;
	this.colors =  colors;

	var font = "sans-serif";
	//var font16 = "10px sans-serif";


	var radius = Math.min(this.width/3,this.height);
	var arc;

	if(isDonut){
		arc = d3.svg.arc().outerRadius(radius - 10).innerRadius(radius - 70);
	}else{
		arc = d3.svg.arc().outerRadius(radius - 10).innerRadius(0);
	}

	var pie = d3.layout.pie()
	.sort(null)
    .value(function(d) {
        return d.value;
    });

    var me = this;

    var svg = d3.select(div).append("svg")
    .attr("width", width)
    .attr("height", height)
    .append("g")
    .attr("id", "pieChart")
    .style("font-family",font)
    .attr("transform", "translate(" + width / 3 + "," + height/2 + ")");

    var arc_grp = svg.append("svg:g")
    .attr("class", "arcGrp")

	var center_group = svg.append("svg:g")
	    .attr("class", "ctrGroup")

	var pieLabel = center_group.append("svg:text")
	    .attr("class", "chartLabel")
	    .attr("text-anchor", "middle")
	    .text("OVERALL");

	var label_group = svg.append("svg:g")
    .attr("class", "lblGroup");
    

	var path = arc_grp.selectAll("path")
    .data(pie(data));


    var legend = svg.append("svg:g")
    						.attr("class","legendGrp")

    						.attr("transform","translate("+ (width*2/3 - radius*2/3) +","+(-1*height/2 + 10)+")")
    						

	var circles = legend.selectAll("g")
						.data(pie(data))

	circles.enter()
		.append("svg:g")
		.append("svg:circle")
			.attr("cx", 0)
			.attr("cy", function(d,i){
				return i*30
			})
			.attr("r", 10)
			.attr("fill",function(d,i){
				//console.log(i);
				return d.data.color
			})


	circles.append("svg:text")
		.text(function(d){
			return d.data.text
		})
		.attr("x",15)
		.attr("y",function(d,i){
			return (i*30)+5
		})
		.style("font-size",14)


	
	circles.exit().remove()

    path.enter()
    .append("svg:path")
    .attr("fill", function(d, i) {
        return d.data.color;
    })
    .attr("stroke", "white").attr("stroke-width", 0.5)
    .on("click",function(d){
    	//console.log(d.data);
        var segment = d3.select(this);
    	me.chartClicked(d,segment);
    })
    .transition().delay(function(d, i) { return i ; }).duration(500)
    .attrTween('d', function(d) {
       var i = d3.interpolate(d.startAngle+0.1, d.endAngle);
       return function(t) {
           d.endAngle = i(t);
         return arc(d);
       }
  	})
    .each(function(d) {
        this._current = d;
    })
   
    path.exit().remove()

    // DRAW SLICE LABELS
	var sliceLabel = label_group.selectAll("text")
    .data(pie(this.data))
    .attr("text-anchor", "middle")


	sliceLabel.enter().append("svg:text")
    .attr("class", "arcLabel")
    .attr("transform", function(d) {
        return "translate(" + arc.centroid(d) + ")"; })
    .attr("text-anchor", "middle").text(function(d, i) {
        return d.data.value });

    sliceLabel.transition()
	    .duration(750)
	    .attr("transform", function(d) {
	        return "translate(" + arc.centroid(d) + ")";
	})
	.style("font-family",font)
	.style("font-size",12)

	sliceLabel.exit().remove();

    this.chartClicked = function(d,segment){
        var sub = d.data.sub;
        var text = d.data.text;
        if(sub){
            me.change(sub.items);
            pieLabel.text(text)
        }
        reset('linechartdiv');
        if(d.data.linkedchart){
            if(d.data.linkedchart.type == "line"){
                var lchart = new linechart("chartdiv",500,400,d.data.linkedchart.items,d.data.text,d.data.color);
                document.getElementById("linechartdiv").appendChild(lchart);
            }else if(d.data.linkedchart.type == "bar"){
                var lchart = new barchart("chartdiv",500,400,d.data.linkedchart.items,d.data.text,d.data.color);
                document.getElementById("linechartdiv").appendChild(lchart);
            }


            this.converge()

            segment.transition()
              .duration(750)
              .attr("transform",function(d){
                  return "translate(" + 
                    (10* Math.sin( ((d.endAngle - d.startAngle) / 2) + d.startAngle ) ) +
                    ", " +
                    (-1 * 10 * Math.cos(((d.endAngle - d.startAngle) / 2) + d.startAngle ) ) +
                  ")";
            })
        }
        return;
    }


    this.converge = function(){
         arc_grp.selectAll("path").transition()
                .duration(100)
                .attr("transform",function(d){
                    return "translate(" + 
                      (Math.sin( ((d.endAngle - d.startAngle) / 2) + d.startAngle)) +
                      ", " +
                      (-1 *Math.cos( ((d.endAngle - d.startAngle) / 2) + d.startAngle)) +
                    ")";
                })
    }

	this.change = function(ndata) {
	    path = path.data(pie(ndata));
	    path.enter().append("path")
	    	.attr("fill",function(d, i){
	    		return d.data.color;
	    	})
	    	.attr("d",arc(enterAntiClockwise))
	    	.each(function(d){
	    		this._current = {
	    			data : d.data,
	    			value : d.value,
	    			startAngle : enterAntiClockwise.startAngle,
	    			endAngle : enterAntiClockwise.endAngle
	    		};
	    	})
	    	.on("click",function(d){
		    	var segment = d3.select(this);
                me.chartClicked(d,segment);
		    })

	    path.exit()
	    	.transition()
	    	.duration(750)
	    	.attrTween('d', this.arcTweenOut)
	    	.remove()


	    path.transition().duration(750).ease("sin").attrTween("d", this.arcTween)
	    .attr("fill", function(d) {
	         return d.data.color;
	     }); // redraw the arcs


	    label_group.selectAll("text").remove();

	    var labels = label_group.selectAll("text")
	    .data(pie(ndata));
	    labels.enter().append("svg:text")
	    .attr("text-anchor", "middle")
	    .text(function(d){
	    	return d.data.value
	    })
	    .style("font-family",font)
		.style("font-size",12)
		.attr("opacity",0)

	    labels.transition()
		    .duration(750)
		    .attr("opacity",1)
		    .attr("transform", function(d) {
		        return "translate(" + arc.centroid(d) + ")";
		})

		labels.exit().remove();



		var legend = svg.selectAll(".legendGrp")
		legend.selectAll("g").remove();
		var circles = legend.selectAll("g")
							.data(pie(ndata))


		circles.enter()
		.append("svg:g")
		.append("svg:circle")
			.attr("cx", 0)
			.attr("cy", function(d,i){
				return i*30
			})
			.attr("r", 10)
			.attr("fill",function(d,i){
				return d.data.color
			})

	   circles.append("svg:text")
		.text(function(d){
			return d.data.text
		})
		.attr("x",15)
		.attr("y",function(d,i){
			return (i*30)+5
		})
		.style("font-size",14)
	}

	// Store the displayed angles in _current.
	// Then, interpolate from _current to the new angles.
	// During the transition, _current is updated in-place by d3.interpolate.

	this.arcTween = function(a) {
	    var i = d3.interpolate(this._current, a);
	    this._current = i(0);
	    return function(t) {
	        return arc(i(t));
	    };
	}

	this.arcTweenOut = function(a) {
	  var i = d3.interpolate(this._current, {startAngle: Math.PI * 2, endAngle: Math.PI * 2, value: 0});
	  this._current = i(0);
	  return function (t) {
	    return arc(i(t));
	  };
	}
	return div;
}

var enterAntiClockwise = {
  startAngle: Math.PI * 2,
  endAngle: Math.PI * 2
};







//=====================================================================//
// var lineData = [{
//   x: 1,
//   y: 5
// }, {
//   x: 20,
//   y: 20
// }, {
//   x: 40,
//   y: 10
// }, {
//   x: 60,
//   y: 40
// }, {
//   x: 80,
//   y: 5
// }, {
//   x: 100,
//   y: 60
// }];


function linechart(divid, width, height, lineData, title, color){
	var div = document.createElement('div');
    div.innerHTML = "<h3 style='margin-left:80px'>"+title+"</h3>"

	 var svg = d3.select(div).append("svg")
    .attr("width", width)
    .attr("height", height)

    WIDTH = width;
    HEIGHT = height; 

    MARGINS = {
      top: 20,
      right: 20,
      bottom: 20,
      left: 50
    },
    

    xRange = d3.scale.linear().range([MARGINS.left, WIDTH - MARGINS.right]).domain([d3.min(lineData, function (d) {
        return d.x;
      }),
      d3.max(lineData, function (d) {
        return d.x;
      })
    ]),

    yRange = d3.scale.linear().range(
        [HEIGHT - MARGINS.top, MARGINS.bottom]).domain([d3.min(lineData, function (d) {
        return d.y;
      }),
      d3.max(lineData, function (d) {
        return d.y;
      })
    ]),

    xAxis = d3.svg.axis()
      .scale(xRange)
      .tickSize(5)
      .tickSubdivide(true),

    yAxis = d3.svg.axis()
      .scale(yRange)
      .tickSize(5)
      .orient("left")
      .tickSubdivide(true);

     //  svg
    	// .append("text")
    	// .text("TITLE");

	  svg.append("svg:g")
	    .attr("class", "x axis")
	    .attr("transform", "translate(0," + (HEIGHT - MARGINS.bottom) + ")")
	    .call(xAxis);

	  svg.append("svg:g")
	    .attr("class", "y axis")
	    .attr("transform", "translate(" + (MARGINS.left) + ",0)")
	    .call(yAxis);

	  var line = d3.svg.line()
	  .x(function (d) {
	    return xRange(d.x);
	  })
	  .y(function (d) {
	    return yRange(d.y);
	  })
	  .interpolate('cardinal');

	var path = svg.append("path")
      .attr("d", line(lineData))
      .attr("stroke", color)
      .attr("stroke-width", "2")
      .attr("fill", "none");

    var totalLength = path.node().getTotalLength();

    path
      .attr("stroke-dasharray", totalLength + " " + totalLength)
      .attr("stroke-dashoffset", totalLength)
      .transition()
        .duration(1000)
        .ease("linear")
        .attr("stroke-dashoffset", 0);

    // svg.on("click", function(){
    //   path      
    //     .transition()
    //     .duration(2000)
    //     .ease("linear")
    //     .attr("stroke-dashoffset", totalLength);
    // })
	return div;
}


function barchart(divid, width, height, barData, title, color){
    var div = document.createElement('div');
    div.innerHTML = "<h3 style='margin-left:80px'>"+title+"</h3>"

     var svg = d3.select(div).append("svg")
    .attr("width", width)
    .attr("height", height)

    WIDTH = width;
    HEIGHT = height; 

    MARGINS = {
      top: 20,
      right: 20,
      bottom: 20,
      left: 50
    },
    

   xRange = d3.scale.ordinal().rangeRoundBands([MARGINS.left, WIDTH - MARGINS.right], 0.1).domain(barData.map(function(d) {
      return d.x;
    }));

    yRange = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain([d3.min(barData, function(d) {
        return d.y;
      }),
      d3.max(barData, function (d) {
        return d.y;
      })
    ]),

    xAxis = d3.svg.axis()
        .scale(xRange)
        .tickSize(5)
        .tickSubdivide(true),

    yAxis = d3.svg.axis()
        .scale(yRange)
        .tickSize(5)
        .orient("left")
        .tickSubdivide(true);

    svg.append('svg:g')
        .attr('class', 'x axis')
        .attr('transform', 'translate(0,' + (HEIGHT - MARGINS.bottom) + ')')
        .call(xAxis);

    svg.append('svg:g')
        .attr('class', 'y axis')
        .attr('transform', 'translate(' + (MARGINS.left) + ',0)')
        .call(yAxis);

    svg.selectAll('rect')
      .data(barData)
      .enter()
      .append("svg:g")
      .attr("class","barg")
      .append('rect')
      .attr('x', function(d) {
        return xRange(d.x);
      })
      .attr('y', function(d) {
        return yRange(d.y);
      })
      .attr('width', xRange.rangeBand())
      .attr('height',0)
        .transition()
        .delay(function (d, i) { return i*100; })
        //.attr("y", function (d, i) { return chartHeight-y(d); })
        //.attr("height", function (d) { return y(d); });

      .attr('height', function(d) {
        return ((HEIGHT - MARGINS.bottom) - yRange(d.y));
      })
      .attr('fill', color)



      svg.selectAll("text.barg")
      .data(barData)
    .enter().append("text")
      .attr("class", "bar")
      .attr("text-anchor", "middle")
      .attr("x", function(d) { return xRange(d.x) + xRange.rangeBand()/2})
      .attr("y", function(d) { return yRange(d.y) - 10;})
      .text(function(d) { return d.y; });

      

      // .on('mouseover', function(d) {
      //   d3.select(this)
      //     .attr('fill', 'blue');
      // })
      // .on('mouseout', function(d) {
      //   d3.select(this)
      //     .attr('fill', 'grey');
      // });

    return div;
}

var piechart = new pie("chartdiv",400,400,pieData.items,"",true);
document.getElementById("chartdiv").appendChild(piechart);


function reset(divid){
	var myNode = document.getElementById(divid);
	while (myNode.firstChild) {
	    myNode.removeChild(myNode.firstChild);
	}
}

function drawMain(){
	var piechart = new pie("chartdiv",400,400,pieData.items,"",true);
	document.getElementById("chartdiv").appendChild(piechart);
}


// var lchart = new linechart("chartdiv",500,400,pieData.items,"",true);
// document.getElementById("linechartdiv").appendChild(lchart);

