var linedata = [{
    "key": "ABC",
    "color": "#B276B2",
    "values": [{
        "Client": "ABC",
        "y": "202",
        "x": "2000"
    }, {
        "Client": "ABC",
        "y": "215",
        "x": "2002"
    }, {
        "Client": "ABC",
        "y": "179",
        "x": "2004"
    }, {
        "Client": "ABC",
        "y": "199",
        "x": "2006"
    }, {
        "Client": "ABC",
        "y": "134",
        "x": "2008"
    }, {
        "Client": "ABC",
        "y": "270",
        "x": "2011"
    }]
}, {
    "key": "XYZ",
    "color": "#FF6D00",
    "values": [{
        "Client": "XYZ",
        "y": "100",
        "x": "2000"
    }, {
        "Client": "XYZ",
        "y": "250",
        "x": "2002"
    }, {
        "Client": "XYZ",
        "y": "179",
        "x": "2004"
    }, {
        "Client": "XYZ",
        "y": "199",
        "x": "2006"
    }, {
        "Client": "XYZ",
        "y": "134",
        "x": "2008"
    }, {
        "Client": "XYZ",
        "y": "176",
        "x": "2013"
    }]
}]







var lineChart = function(config){
    var container = document.getElementById(config.containerId);


    container.setAttribute("style","width:"+ config.width +"px;height:"+ config.height +"px;");
    //container.setAttribute("style","width:100%;height:100%;");
	var data = config.data;
    var WIDTH = config.width-30;
	var HEIGHT = config.height-30;
	var MARGINS = {
        top: 50,
        right: 20,
        bottom: 50,
        left: 50
    }

	//var div = document.createElement('div');
	var chart = d3.select(container);

    //tooltip//
    if(config.tooltip){
        var t = document.createElement("div");
        container.appendChild(t);
        var tooltip = d3.select(t);
        tooltip.attr("class","toolTip")
    }
    ///////////

	var vis = chart.append("svg")
	.attr("width",config.width-30)
    .attr("height",config.height-30)
    //.attr('viewBox','0 0 '+Math.min(config.width,config.height) +' '+Math.min(config.width,config.height) )
    .attr('preserveAspectRatio','xMinYMin')

    xScale = d3.scale.linear().range([MARGINS.left, WIDTH - MARGINS.right]).domain(config.xDomain);
    yScale = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain(config.yDomain);

    xAxis = d3.svg.axis()
        .scale(xScale).tickFormat(d3.format("d")),
  
    yAxis = d3.svg.axis()
        .scale(yScale);

    // vis.append("svg:g")
    //     .call(xAxis);

    vis.append("svg:g")
        .attr("class","axis")
        .attr("transform", "translate(0," + (HEIGHT - MARGINS.bottom) + ")")
        .call(xAxis);

    // vis.append("svg:g")
    //     .call(yAxis);

    yAxis = d3.svg.axis()
        .scale(yScale)
        .orient("left");

    vis.append("svg:g")
        .attr("class","axis")
        .attr("transform", "translate(" + (MARGINS.left) + ",0)")
        .call(yAxis);



    var lineGen = d3.svg.line()
      .x(function(d) {
        return xScale(d.x);
      })
      .y(function(d) {
        return yScale(d.y);
      })
      .interpolate(config.interpolate);


    var lSpace = WIDTH/config.data.length;

    data.forEach(function(d, i) {
        var path = vis.append('svg:path')
        .attr('d', lineGen(d.values))
        .attr('stroke', function() {
                if(d.color){
                    return d.color
                }else{
                    return "hsl(" + Math.random() * 360 + ",100%,50%)";
                }
            }
        )
        .attr('stroke-width', 2)
        .attr('fill', 'none')
        .attr('id', 'line_'+d.key);

        var totalLength = path.node().getTotalLength();

        path.attr("stroke-dasharray", totalLength + " " + totalLength)
        .attr("stroke-dashoffset", totalLength)
        .transition()
        .duration(1000)
        .ease("linear")
        .attr("stroke-dashoffset", 0)
        
        vis.selectAll("text")
        .attr("fill",config.labelColor)
        


        vis.append("text")
        .attr("x", (lSpace / 2) + i * lSpace)
        .attr("y", HEIGHT)
        .style("fill", d.color)
        .style("font-weight","bold")
        .style("cursor","pointer")
        .text(d.key)
        .on('click', function() {
            var active = d.active ? false : true;
            var opacity = active ? 0 : 1;
            d3.select("#line_" + d.key)
            .transition()
            .duration(500).style("opacity", opacity);
            d.active = active;
        });
    });
    //document.getElementById(config.containerId).appendChild(div);
}


