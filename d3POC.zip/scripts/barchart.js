var bardata = {
    "key": "ABC",
    "color": "#5C6BC0",
    "values": [{
        "text": "ABC",
        "y": "202",
        "x": "2000",
        "sub":[
          {
              "text": "q1",
              "y": "20",
              "x": "2002",
              "sub":[
                {
                  "text": "JAN",
                  "y": "70",
                  "x": "2004"
                },
                {
                  "text": "FEB",
                  "y": "30",
                  "x": "2005"
                },
              ]
          }, {
              "text": "ABC",
              "y": "30",
              "x": "2004"
          }, {
              "text": "ABC",
              "y": "40",
              "x": "2006"
          }
        ]
    }, {
        "text": "ABC",
        "y": "215",
        "x": "2002"
    }, {
        "text": "ABC",
        "y": "179",
        "x": "2004"
    }, {
        "text": "ABC",
        "y": "199",
        "x": "2006"
    }, {
        "text": "ABC",
        "y": "134",
        "x": "2008"
    }, {
        "text": "ABC",
        "y": "270",
        "x": "2011"
    }]
}





function barchart(config){
    var me = this;
    var div = document.getElementById(config.containerId);

    div.setAttribute("style","display:block;width:"+ config.width +"px;height:"+ config.height+"px;");
    //div.setAttribute("style","width:100%;height:100%;");

    // if(config.heading){
    //   div.innerHTML = config.heading.html;
    // }


    //d3.select(div).style("min-width",config.width)
    //d3.select(div).style("min-height",config.height)

    if(config.drilldown){
      var nbar = document.createElement("div");
      nbar.setAttribute("style","width:100%;height:40px;clear:both")
      var nav_ul = document.createElement("ul");
      nbar.className = "crumbs";
      nbar.appendChild(nav_ul);
      
      div.appendChild(nbar);
    }

    this.prev_data = "";

     var svg = d3.select(div).append("svg")
    .attr("width",'100%')
    .attr("height",'100%')
    .attr('viewBox','0 0 '+Math.min(config.width,config.height) +' '+Math.min(config.width,config.height) )
    .attr('preserveAspectRatio','xMinYMin')

    WIDTH = config.width;
    HEIGHT = config.height; 

    MARGINS = {
      top: 20,
      right: 20,
      bottom: 20,
      left: 50
    }


    this.update = function(data,prevdata,item){
      svg.selectAll("g,text").remove();
      xRange = d3.scale.ordinal().rangeRoundBands([MARGINS.left, WIDTH - MARGINS.right], 0.1).domain(data.map(function(d) {
        return d.x;
      }));

      yRange = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain([d3.min(data, function(d) {
          return d.y - 10;
        }),
        d3.max(data, function (d) {
          return d.y;
        })
      ]),

      xAxis = d3.svg.axis()
          .scale(xRange)
          //.tickSize(5)
          .tickSubdivide(true),

      yAxis = d3.svg.axis()
          .scale(yRange)
          //.tickSize(5)
          .orient("left")
          .tickSubdivide(true);

      svg.append('svg:g')
          .attr('class', 'x axis')
          .attr('transform', 'translate(0,' + (HEIGHT - MARGINS.bottom) + ')')
          .call(xAxis);

      svg.append('svg:g')
          .attr('class', 'y axis')
          .attr('transform', 'translate(' + (MARGINS.left) + ',0)')
          .call(yAxis);

      svg.selectAll('rect')
        .data(data)
        .enter()
        .append("svg:g")
        .attr("class","barg")
        .append('rect')
        .attr('x', function(d) {
          return xRange(d.x);
        })
        .attr('y', function(d) {
          return yRange(d.y);
        })
        .attr('width', xRange.rangeBand())
        .on("click",function(d){
          if(d.sub){
            me.prev_data = data;
            me.update(d.sub,data,d)
          }
        })
        .on("mouseover",function(d){
          d3.select(this)
          .attr("fill","#7986CB");
        })
        .on("mouseout",function(d){
          d3.select(this)
          .attr("fill",config.color);
        })
        .attr("cursor","pointer")
        .attr('height',0)
          .transition()
          .delay(function (d, i) { return i*100; })
          //.attr("y", function (d, i) { return chartHeight-y(d); })
          //.attr("height", function (d) { return y(d); });

        .attr('height', function(d) {
          return ((HEIGHT - MARGINS.bottom) - yRange(d.y));
        })
        .attr('fill', config.color)
       
      svg.selectAll("text.barg")
      .data(data)
      .enter().append("text")
      .attr("class", "bar")
      .attr("text-anchor", "middle")
      .attr("x", function(d) { return xRange(d.x) + xRange.rangeBand()/2})
      .attr("y", function(d) { return yRange(d.y) - 10;})
      .text(function(d) { return d.y; });


      if(prevdata){
            var label = "back";
            if(item){
              label = item.text
            }
            if(config.drilldown){
              var li = document.createElement("li")
              var a = document.createElement("a");
              a.innerHTML = label;
              li.appendChild(a);
              li.style.backgroundColor = config.color;
              a.style.color = "#fff"
              a.style.borderColor = config.color;
              li.addEventListener("click",function(){
                  me.update(prevdata);
                  var ns;
                  var curr_li = a.parentNode;
                  while(ns = curr_li.nextSibling){
                      nav_ul.removeChild(ns);
                  }
                  nav_ul.removeChild(curr_li);
              })
              nav_ul.appendChild(li);
          }
        }
    }


    var update = this.update(config.data.values);
    //div.appendChild(nbar);
    return div;
}

