
var pieChart = function(config,callback){
    this.updating = false;
    var container = document.getElementById(config.containerId);


    container.setAttribute("style","display:block;width:"+ config.width +"px;height:"+ config.height+"px;");

    if(config.tooltip){
        var t = document.createElement("div");
        container.appendChild(t);
        var tooltip = d3.select(t);
        tooltip.attr("class","toolTip")
    }

    
    var width = config.width;
    var height = config.height;

    var me = this;
    this.prev_data = config.data;

    this.curr_level = 0;
    this.label_arr = [];


    var radius = Math.min(width,height-40)/2;
    
    if(config.legend){
        radius = (width)/3;
    }
    var pie = d3.layout.pie()
        .value(function(d){ return d.value })
        .sort(null);

    var arc = d3.svg.arc()
            .innerRadius(config.donutRadius)
            .outerRadius(radius - 20);

    var tx = (config.legend)?(width/3):(width/2)

    var svg = d3.select(container)
        .append("svg")
        .attr("width",'100%')
        .attr("height",'100%')
        .attr('viewBox','0 0 '+Math.min(width,height) +' '+Math.min(width,height))
        .attr('preserveAspectRatio','xMinYMin')
        .append("g")
        .attr("font","sans-serif")
        .attr("font-size","18px")

    var arc_grp = svg.append("svg:g")
        .attr("class", "arcGrp")
        .attr("transform","translate("+ tx +","+ height/2 +")")

    var center_group = svg.append("svg:g")
        .attr("class", "ctrGroup")
        .attr("transform","translate("+ tx +","+ height/2 +")")

    var label_group = svg.append("svg:g")
        .attr("class", "lblGroup")
        .attr("transform","translate("+ tx +","+ height/2 +")")

    var nav_group = svg.append("svg:g")
        .attr("class","nav_group");

    // var heading = svg.append("svg:g")
    //     .attr("class","heading")
    //     .append("svg:text")
    //     .text(config.heading)
    //     .attr("transform","translate("+ 20 +","+ 30 +")")

    var legend_group = svg.append("svg:g")
        .attr("class","legend_group")
        .attr("transform","translate("+ tx +","+ height/2 +")")

    var path = arc_grp.selectAll("path")
        .data(pie(config.data));
    
    var sliceLabel = label_group.selectAll("text")
        .data(pie(config.data))
        .attr("text-anchor", "middle");


    path.enter()
        .append("svg:path")
        .attr("fill",function(d){
            return d.data.color
        })
        .style("cursor",function(d){
            if(d.data.sub){
                return "pointer"
            }
        })
        .on("click",function(d){
            var segment = d3.select(this);
            if(d.data.sub){
                me.updating = true;
                me.update(d.data.sub,me.prev_data,d.data.text,d.data.color);
                me.curr_level++;
            }
            if(callback){
                callback(d);
            }
        })
        .transition().delay(function(d, i) {return i}).duration(config.transitionDuration)
        .attrTween('d', function(d) {
            var i = d3.interpolate(d.startAngle+0.1, d.endAngle);
            return function(t) {
                d.endAngle = i(t);
                return arc(d);
            }
        })
        .each(function(d) {
            this._current = d;
        })
    path.exit().remove()

    // if(config.tooltip){
    //     path.on("mousemove", function(d){
    //         tooltip.style("left", d3.event.pageX+"px");
    //         tooltip.style("top", d3.event.pageY+"px");
    //         tooltip.style("display", "block");
    //         tooltip.style("opacity","0");
    //         tooltip.transition()
    //         .duration(500).
    //         style("opacity", "100");
    //         tooltip.html((d.data.text)+"<br>"+(d.data.value));
    //     });

    //     path.on("mouseout", function(d){
    //         tooltip.transition().duration(500).style("opacity", "0");
    //     });
    // }

    if(config.labels){
        sliceLabel.enter().append("svg:text")
            .attr("class", "arcLabel")
            .attr("fill",config.labelColor)
            .attr("transform", function(d) {
                return "translate(" + arc.centroid(d) + ")"; })
            .attr("text-anchor", "middle").text(function(d) {
                return d.value });

        sliceLabel.transition()
            .duration(750)
            .attr("transform", function(d) {
                return "translate(" + arc.centroid(d) + ")";
            })
            .style("font-family","sans-serif")
            .style("font-size",16)

        sliceLabel.exit().remove();
    }


   this.drawLegend=function(ldata){
        var legendRectSize = 12;
        var legendSpacing = 10;
        var legendFontSize = 14;
        //var font_size = 14;
        svg.select('.legend_group').selectAll("g").remove();

        var legend = svg.select('.legend_group')
            .selectAll("g")
            .data(ldata)
            .enter()
            .append('g')
            .attr('class', 'legend')
            .attr('transform', function(d, i) {
                var length = this.parentNode.childNodes.length;
                var height = legendRectSize + legendSpacing;
                var offset =  height * length / 2;
                var horz = -2 * legendRectSize;
                var vert = i * height - offset;
                return 'translate(' + horz + ',' + vert + ')';
            });

        legend.append('rect')
            .attr('width', legendRectSize)
            .attr('height', legendRectSize)
            .style('fill', function(d){
                return d.color
            })
            .style('stroke', function(d){
                return d.color
            })
            .attr("opacity",0)
            .transition()
            .duration(750)
            .attr("opacity",1)
       
        legend.append('text')
            .attr('x', legendRectSize + legendSpacing)
            .attr('y', 0 + legendSpacing + 2)
            .text(function(d) { return d.text })
            .attr("fill",config.labelColor)
            .style("font-size",legendFontSize)
            .attr("opacity",0)
            .transition()
            .duration(750)
            .attr("opacity",1)

        var lg = svg.select(".legend_group")

        lg.attr("transform","translate("+ width*3 +","+ height/2 +")")
        .transition()
        .duration(750)
        .attr("transform","translate("+ ((radius*2)+legendRectSize+10) +","+ height/2 +")")
    }

    if(config.legend){
        me.drawLegend(config.data);
    }

    this.initializeBreadcrumbTrail = function() {
      svg.append("svg:svg")
          .attr("width", '100%')
          .attr("height", 50)
          .attr("id", "trail")
          .attr("transform","translate(0,0)")
    }

    var b = {
          w: 60, h: 25, s: 3, t: 10
    };

    this.breadcrumbPoints = function(d, i) {
      var points = [];
      points.push("0,0");
      points.push(b.w + ",0");
      points.push(b.w + b.t + "," + (b.h / 2));
      points.push(b.w + "," + b.h);
      points.push("0," + b.h);
      if (i > 0) { // Leftmost breadcrumb; don't include 6th vertex.
        points.push(b.t + "," + (b.h / 2));
      }
      return points.join(" ");
    }

    this.updateBreadcrumbs = function(nodeArray, prevdata) {
      var g = svg.select("#trail")
          .selectAll("g")
          .data(nodeArray, function(d,i) { 
            return d + i; 
        })

      var entering = g.enter()
      .append("svg:g").on("click",function(d){
        if(me.label_arr.indexOf(d) != -1){
            me.label_arr.length = me.label_arr.indexOf(d);
        }
        me.update(prevdata);
      })

      entering.append("svg:polygon")
          .attr("points", me.breadcrumbPoints)
          .style("fill", function(d){
            return d.color;
          })

      entering.append("svg:text")
          .attr("x", (b.w + b.t) / 2)
          .attr("y", b.h / 2)
          .attr("dy", "0.35em")
          .attr("text-anchor", "middle")
          .text(function(d) { return d.label})
          .attr("fill",config.labelColor)

      g.attr("transform", function(d, i) {
        return "translate(" + i * (b.w + b.s) + ", 0)";
      });

      g.exit().remove();
    } 

    this.update = function(newdata,prevdata,label,color){
        if(label){
            label = label.toUpperCase();
            if(label.length > 3){
                label = label.substring(0,3);

            }
            me.label_arr.push({"label":label,"color":color});
        }
        me.initializeBreadcrumbTrail();
        me.updateBreadcrumbs(me.label_arr,prevdata);

        var enterAntiClockwise = {
          startAngle: Math.PI * 2,
          endAngle: Math.PI * 2
        };
        // var k = 0;

        // svg.select(".nav_group")
        //     .selectAll("text")
        //     .each(function(d){
        //         k = k + this.getBBox().width + 20;
        //     })
        // if(prevdata && config.drilldown){
            
        // }

        this.prev_data = newdata;

        path = path.data(pie(newdata));
        
        path.enter()
            .append("svg:path")
            .attr("d",arc(enterAntiClockwise))
            .style("cursor",function(d){
                if(d.data.sub){
                    return "pointer"
                }
            })
            .each(function(d){
                this._current = {
                    data : d.data,
                    value : d.value,
                    startAngle : enterAntiClockwise.startAngle,
                    endAngle : enterAntiClockwise.endAngle
                };
            })
            .on("click",function(d){
                var segment = d3.select(this);
                if(d.data.sub){
                    me.update(d.data.sub,prevdata,d.text);
                }
                callback(d)
            })
        path.exit()
            .transition()
            .duration(config.transitionDuration)
            .attrTween('d', this.arcTweenOut)
            .remove()


        path.transition().duration(config.transitionDuration).ease(config.drilldownTransition).attrTween("d", this.arcTween)
        .attr("fill", function(d) {
             return d.data.color;
         }); // redraw the arcs

        if(config.labels){
            label_group.selectAll("text").remove();

            var labels = label_group.selectAll("text")
                .data(pie(newdata));
                labels.enter().append("svg:text")
                .attr("text-anchor", "middle")
                .text(function(d){
                    return d.data.value
                })
                .style("font-family","sans-serif")
                .style("font-size",16)
                .attr("opacity",0)
                .attr("fill",config.labelColor)

            labels.transition()
                .duration(config.transitionDuration)
                .attr("opacity",1)
                .attr("transform", function(d) {
                    return "translate(" + arc.centroid(d) + ")";
                })

            labels.exit().remove();
        }

        if(config.legend){
            me.drawLegend(newdata);
        }
        setTimeout(function(){
        me.updating=false;
        },500);


        
    } 


     

    this.arcTween =function(a) {
      var i = d3.interpolate(this._current, a);
      this._current = i(0);
      return function(t) {
        return arc(i(t));
      };
    }
    this.arcTweenOut = function(a) {
      var i = d3.interpolate(this._current, {startAngle: Math.PI * 2, endAngle: Math.PI * 2, value: 0});
      this._current = i(0);
      return function (t) {
        return arc(i(t));
      };
    }
}






