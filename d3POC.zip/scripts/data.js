var pie1 = [
    {
        "text": "BFS",
        "value": 30,
        "color": "#7E57C2"
    },
    {
        "text": "RETAIL",
        "value": 40,
        "color": "#00BCD4"
    },
    {
        "text": "TELECOM",
        "color": "#4CAF50",
        "value": 50
    }
]


var bar1 = {
    "key": "ABC",
    "color": "#5C6BC0",
    "values": [
        {
            "text": "ABC",
            "y": "202",
            "x": "2000",
        },
        {
            "text": "ABC",
            "y": "215",
            "x": "2002"
        },
        {
            "text": "ABC",
            "y": "179",
            "x": "2004"
        },
        {
            "text": "ABC",
            "y": "199",
            "x": "2006"
        },
        {
            "text": "ABC",
            "y": "134",
            "x": "2008"
        },
        {
            "text": "ABC",
            "y": "270",
            "x": "2011"
        }]
}

var chartData = [
    {
        "text": "BFS",
        "value": 30,
        "color": "#7E57C2",
        "sub": [
            {
                "text": "CBQ",
                "color": "#00C853",
                "value": 40,
                "sub": [
                    {
                        "text": "RIB",
                        "color": "#5DA5DA",
                        "value": 80,
                        "sub": [
                            {
                                "text": "Q1",
                                "color": "#5DA5DA",
                                "value": 80
                            },
                            {
                                "text": "Q2",
                                "color": "#DECF3F",
                                "value": 10
                            },
                            {
                                "text": "Q3",
                                "color": "#4CAF50",
                                "value": 20
                            }
                        ]
                    },
                    {
                        "text": "CBTouch",
                        "color": "#DECF3F",
                        "value": 10
                    },
                    {
                        "text": "EMB",
                        "color": "#4CAF50",
                        "value": 20
                    },
                    {
                        "text": "RIB Revamp",
                        "color": "#00C853",
                        "value": 60
                    }
                ]
            },
            {
                "text": "CITY",
                "color": "#FFC107",
                "value": 30
            },
            {
                "text": "BOA",
                "color": "#00BCD4",
                "value": 60
            }
        ]
    },
    {
        "text": "RETAIL",
        "value": 40,
        "color": "#00BCD4",
        "sub": [
            {
                "text": "WALMART",
                "color": "#5DA5DA",
                "value": 80
            },
            {
                "text": "HOMEDIPOT",
                "color": "#DECF3F",
                "value": 10
            },
            {
                "text": "UB",
                "color": "#4CAF50",
                "value": 20
            }
        ]
    },
    {
        "text": "TELECOM",
        "color": "#4CAF50",
        "value": 50,
        "sub": [
            {
                "text": "Motorola",
                "color": "#00BCD4",
                "value": 40
            },
            {
                "text": "Cisco",
                "color": "#4CAF50",
                "value": 50
            }
        ]
    }
]



var master = {
    "items": [
        {
            "type": "pie",
            "config": {
                containerId: "chartContainer",
                width: 250,
                height: 300,
                labels: true,
                legend: false,
                //data: chartData,
                heading: "Mobility",
                showText: true,
                drilldown: false,
                tooltip: true,
                inner: "drilldown",
                transition: "linear",
                transitionDuration: 750,
                donutRadius: 0,
                labelColor: "#fff",
                strokeWidth: 3,
                drilldownTransition: "linear",
                data: [
                    {
                        "text": "BFS",
                        "value": 30,
                        "color": "#FF5252",
                        "sub": [
                            {
                                "text": "Q1",
                                "color": "#5DA5DA",
                                "value": 80
                            },
                            {
                                "text": "Q2",
                                "color": "#DECF3F",
                                "value": 10
                            },
                            {
                                "text": "Q3",
                                "color": "#4CAF50",
                                "value": 20
                            }
                        ]
                  },
                    {
                        "text": "RETAIL",
                        "value": 40,
                        "color": "#8BC34A"
                  },
                    {
                        "text": "TELECOM",
                        "color": "#00BCD4",
                        "value": 50
                  }
                ]
            }//,

            // expand:
            // {
            //     "type": "pie",
            //     "config": {
            //         containerId: "chartContainerE",
            //         width: 500,
            //         height: 500,
            //         labels: true,
            //         legend: true,
            //         //data: chartData,
            //         heading: "Mobility",
            //         showText: true,
            //         drilldown: true,
            //         tooltip: true,
            //         inner: "drilldown",
            //         transition: "linear",
            //         transitionDuration: 750,
            //         donutRadius: 0,
            //         labelColor: "#fff",
            //         strokeWidth: 3,
            //         drilldownTransition: "linear",
            //         data: [
            //             {
            //                 "text": "BFS",
            //                 "value": 30,
            //                 "color": "#FF5252",
            //                 // "sub": [
            //                 //     {
            //                 //         "text": "Q1",
            //                 //         "color": "#5DA5DA",
            //                 //         "value": 80
            //                 //     },
            //                 //     {
            //                 //         "text": "Q2",
            //                 //         "color": "#DECF3F",
            //                 //         "value": 10
            //                 //     },
            //                 //     {
            //                 //         "text": "Q3",
            //                 //         "color": "#4CAF50",
            //                 //         "value": 20
            //                 //     }
            //                 // ]
            //           },
            //             {
            //                 "text": "RETAIL",
            //                 "value": 40,
            //                 "color": "#00BCD4"
            //           },
            //             {
            //                 "text": "TELECOM",
            //                 "color": "#4CAF50",
            //                 "value": 50
            //           }
            //         ]
            //     }
            // }
        },
        {
            "type": "pie",
            "config": {
                "containerId": "chartContainer1",
                "width": 350,
                "height": 300,
                "labels": true,
                "legend": true,
                //"data": chartData,
                "heading": "Mobility",
                "showText": true,
                "drilldown": true,
                "tooltip": true,
                "inner": "drilldown",
                "transition": "linear",
                "transitionDuration": 750,
                "donutRadius": 40,
                labelColor: "#fff",
                //strokeWidth: 3,
                "drilldownTransition": "linear",

                "data": [
                    {
                        "text": "BFS",
                        "value": 30,
                        "color": "#FF5252"
                  },
                    {
                        "text": "RETAIL",
                        "value": 40,
                        "color": "#8BC34A"
                  },
                    {
                        "text": "TELECOM",
                        "color": "#00BCD4",
                        "value": 50
                  }
                ]
            }
        },
        {
            "type": "line",
            "config": {
                containerId: "lineContainer",
                width: 480,
                height: 300,
                labels: true,
                legend:true,
                xDomain:[2000,2015],
                yDomain:[100,300],
                tooltip:true,
                //callback:segmentClick(),
                heading: "Mobility",
                labelColor: "#fff",
                showText:true,
                tooltip:true,
                inner: "drilldown",
                transition: "linear",
                transitionDuration: 750,
                interpolate:"basis",
                "data": [
                    {
                        "key": "ABC",
                        "color": "#B276B2",
                        "values": [
                            {
                                "Client": "ABC",
                                "y": "202",
                                "x": "2000"
                            },
                            {
                                "Client": "ABC",
                                "y": "215",
                                "x": "2002"
                            },
                            {
                                "Client": "ABC",
                                "y": "179",
                                "x": "2004"
                            },
                            {
                                "Client": "ABC",
                                "y": "199",
                                "x": "2006"
                            },
                            {
                                "Client": "ABC",
                                "y": "134",
                                "x": "2008"
                            },
                            {
                                "Client": "ABC",
                                "y": "270",
                                "x": "2011"
                            }
                        ]
                    },
                    {
                        "key": "XYZ",
                        "color": "#FF6D00",
                        "values": [
                            {
                                "Client": "XYZ",
                                "y": "100",
                                "x": "2000"
                            },
                            {
                                "Client": "XYZ",
                                "y": "250",
                                "x": "2002"
                            },
                            {
                                "Client": "XYZ",
                                "y": "179",
                                "x": "2004"
                            },
                            {
                                "Client": "XYZ",
                                "y": "199",
                                "x": "2006"
                            },
                            {
                                "Client": "XYZ",
                                "y": "134",
                                "x": "2008"
                            },
                            {
                                "Client": "XYZ",
                                "y": "176",
                                "x": "2013"
                            }
                        ]
                    }
               ]
            }
        }
    ]
}