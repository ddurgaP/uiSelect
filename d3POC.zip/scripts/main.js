//linechart
var lineConfig = {
    containerId: "lineContainer",
    width: 600,
    height: 300,
    labels: true,
    legend:true,
    data: linedata,
    xDomain:[2000,2015],
    yDomain:[100,300],
    tooltip:true,
    //callback:segmentClick(),
    heading: "Mobility",

    showText:true,
    tooltip:true,
    inner: "drilldown",
    transition: "linear",
    transitionDuration: 750,
    interpolate:"basis"
}
var linec = new lineChart(lineConfig);



//piechart
var config = {
    containerId: "chartContainer",
    width: 300,
    height: 300,
    labels: true,
    legend:true,
    data: chartData,
    //callback:segmentClick(),
    heading: {
        html: "<h3 style='margin:0;padding:0;'>Mobility</h3>",
    },

    showText:true,
    drilldown:true,
    tooltip:true,
    inner: "drilldown",
    transition: "linear",
    transitionDuration: 750,
    donutRadius: 0,
    gradient: true,
    colors: d3.scale.category20(),
    labelColor: "white",
    stroke: "#eee",
    strokeWidth: 3,
    drilldownTransition: "linear"
};
segmentClick = function(d){
    console.log(d);
}
var chart = new pieChart(config,segmentClick);
//////////////////////////////////////////////


//barchart
var barConfig = {
    containerId: "barContainer",
    width: 970,
    height: 400,
    labels: true,
    legend:true,
    data: bar1,
    xDomain:[2000,2015],
    yDomain:[100,300],
    color:bardata.color,
    //callback:segmentClick(),
    heading: {
        html: "<h3 style='margin:0;padding:0;'>Mobility</h3>",
    },
    drilldown:false,
    showText:true,
    tooltip:false,
    inner: "drilldown",
    transition: "linear",
    transitionDuration: 750,
    interpolate:"linear"
}
var barc = new barchart(barConfig);