var app = angular.module('plunker', ['nvd3']);

app.controller('MainCtrl', function($scope) {
 $scope.options = {
            
  chart: {
    "type": "pieChart",
    "height": 450,
    "donut": true,
    "showLabels": true,
    "pie": {
      "dispatch": {},
      "arcsRadius": [{"inner":0.6,"outer":0.8}],
      "width": 500,
      "strokeWidth":5,
      "height": 500,
      "showLabels": true,
      "title": false,
      "titleOffset": 0,
      "labelThreshold": 0.02,
      "id": 1727,
      "padAngle": false,
      "cornerRadius": 0,
      "donutRatio": 0.5,
      "labelsOutside": false,
      "labelSunbeamLayout": false,
      "donut": false,
      "growOnHover": true,
      "pieLabelsOutside": false,
      "donutLabelsOutside": false,
      "margin": {
        "top": 0,
        "right": 0,
        "bottom": 0,
        "left": 0
      },
      "labelType": "key"
    },
    "duration": 500,
    "legend": {
      "margin": {
        "top": 5,
        "right": 140,
        "bottom": 5,
        "left": 0
      },
      "dispatch": {},
      "width": 400,
      "height": 20,
      "align": true,
      "maxKeyLength": 20,
      "rightAlign": true,
      "padding": 32,
      "updateState": true,
      "radioButtonMode": false,
      "expanded": false,
      "vers": "classic"
    },
    "dispatch": {},
    "tooltip": {
      "duration": 0,
      "gravity": "w",
      "distance": 25,
      "snapDistance": 0,
      "classes": null,
      "chartContainer": null,
      "enabled": true,
      "hideDelay": 200,
      "headerEnabled": false,
      "fixedTop": null,
      "offset": {
        "left": 0,
        "top": 0
      },
      "hidden": true,
      "data": null,
      "id": "nvtooltip-34884"
    },
    "arcsRadius": [{"inner":0.6,"outer":0.7},{"inner":0.6,"outer":0.7}],
    "width": null,
    "title": false,
    "titleOffset": 0,
    "labelThreshold": 0.02,
    "padAngle": false,
    "cornerRadius": 0,
    "donutRatio": 0.5,
    "labelsOutside": false,
    "labelSunbeamLayout": false,
    "growOnHover": true,
    "pieLabelsOutside": false,
    "donutLabelsOutside": false,
    "margin": {
      "top": 30,
      "right": 20,
      "bottom": 20,
      "left": 20
    },
    "labelType": "key",
    "noData": null,
    "showLegend": true,
    "legendPosition": "top",
    "defaultState": null
  },
  "title": {
    "enable": false,
    "text": "Write Your Title",
    "className": "h4",
    "css": {
      "width": "nullpx",
      "textAlign": "center"
    }
  },
  "subtitle": {
    "enable": true,
    "text": "Write Your Subtitle",
    "css": {
      "width": "nullpx",
      "textAlign": "center"
    }
  },
  "caption": {
    "enable": true,
    "text": "Figure 1. Write Your Caption text.",
    "css": {
      "width": "nullpx",
      "textAlign": "center"
    }
  },
  "styles": {
    "classes": {
      "with-3d-shadow": true,
      "with-transitions": true,
      "gallery": false
    },
    "css": {}
  }

        };

        $scope.data = [
            {
                key: "One",
                y: 5
            },
            {
                key: "Two",
                y: 2
            },
            
        ];
});
