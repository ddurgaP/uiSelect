Read more about Angular-nvD3:
http://krispo.github.io/angular-nvd3/