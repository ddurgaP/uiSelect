package jsonExporter;


import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.FileReader;
import java.util.List;
import java.util.Map;
import org.json.simple.parser.JSONParser;

import net.sf.json.JSONObject;


	public class MainExporter {
	    public static void main(String[] args) throws Exception {
	        JsonFlattener parser = new JsonFlattener();
	        CSVWriter writer = new CSVWriter();
	        JSONParser jsonParser = new JSONParser();

	        /*Map<String, String> flatJson;*/
	        List<Map<String, String>> flatJson;
	        //writer.writeAsCSV(flatJson, "sample.csv");
	        
	        flatJson = parser.parseJson(FileUtils.readFileToString(new File("files/testJson.json"), "UTF-8"));
	        writer.writeAsCSV(flatJson, "sample.csv");
	        
	       /* Object object = jsonParser.parse(new FileReader("files/sampleJson.json"));
	        JSONObject jsonObject = (JSONObject)object;
	        flatJson = parser.parse(jsonObject);*/
	        
	        
	    }

	    private static String jsonValue() {
	        return "[\n" +
	                "    {\n" +
	                "        \"studentName\": \"Foo\",\n" +
	                "        \"Age\": \"12\",\n" +
	                "        \"subjects\": [\n" +
	                "            {\n" +
	                "                \"name\": \"English\",\n" +
	                "                \"marks\": \"40\"\n" +
	                "            },\n" +
	                "            {\n" +
	                "                \"name\": \"History\",\n" +
	                "                \"marks\": \"50\"\n" +
	                "            }\n" +
	                "        ]\n" +
	                "    },\n" +
	                "    {\n" +
	                "        \"studentName\": \"Bar\",\n" +
	                "        \"Age\": \"12\",\n" +
	                "        \"subjects\": [\n" +
	                "            {\n" +
	                "                \"name\": \"English\",\n" +
	                "                \"marks\": \"40\"\n" +
	                "            },\n" +
	                "            {\n" +
	                "                \"name\": \"History\",\n" +
	                "                \"marks\": \"50\"\n" +
	                "            },\n" +
	                "            {\n" +
	                "                \"name\": \"Science\",\n" +
	                "                \"marks\": \"40\"\n" +
	                "            }\n" +
	                "        ]\n" +
	                "    },\n" +
	                "    {\n" +
	                "        \"studentName\": \"Baz\",\n" +
	                "        \"Age\": \"12\",\n" +
	                "        \"subjects\": []\n" +
	                "    }\n" +
	                "]";
	    }
	}

